version = 1116
versionString = "3.1.0"
versionNameAppendix = "_%s" % str(version)
